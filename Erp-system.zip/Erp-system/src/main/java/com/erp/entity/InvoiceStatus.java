package com.erp.entity;

public enum InvoiceStatus {
    PAID, UNPAID
}
