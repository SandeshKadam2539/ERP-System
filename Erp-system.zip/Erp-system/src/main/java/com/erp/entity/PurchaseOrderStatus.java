package com.erp.entity;

public enum PurchaseOrderStatus {
    ORDERED,
    RECEIVED,
    CANCELLED
}
