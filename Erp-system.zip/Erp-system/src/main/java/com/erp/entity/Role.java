package com.erp.entity;

public enum Role {
    ADMIN,
    SALES_EXECUTIVE,
    CUSTOMER
}
