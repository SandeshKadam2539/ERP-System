package com.erp.entity;

public enum SalesOrderStatus {
    PENDING,
    APPROVED,
    DISPATCHED
}
