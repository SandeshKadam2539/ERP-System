package com.erp.repository;

import com.erp.entity.GRN;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GRNRepository extends JpaRepository<GRN, Long> {
}
